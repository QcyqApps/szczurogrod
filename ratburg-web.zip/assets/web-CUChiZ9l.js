import{W as n}from"./index-yzgcgK2a.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
